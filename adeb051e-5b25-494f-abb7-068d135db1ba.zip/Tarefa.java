package org.RegistrarTarefas;

public class Tarefa {

    private String titulo;
    private String descricao;
    private String status;

    public Tarefa(String titulo, String descricao) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.status = "Pendente";
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getStatus() {
        return status;
    }

    public void concluir() {
        this.status = "Concluída";
    }

    public Tarefa buscarPorNome(String qualquer) {
        this.buscarPorNome(qualquer);
        return this;
    }


}