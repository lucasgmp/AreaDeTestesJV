package org.RegistrarTarefas;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertThrows;

public class DummyTest {
    @Test
     void deveusarDummyTest(){
        TarefaRepository dummy = new TarefaRepository(){
            @Override
            public void salvar(Tarefa tarefa) {

            }
            @Override
            public Tarefa BuscaPorNomes(String nome){
                return null;
            }

            @Override
            public Tarefa buscarPorNome(String nome) {
                return null;
            }
        };
        TarefaService service = new TarefaService(dummy);
        assertThrows(IllegalArgumentException.class, () -> {
            service.cadastrarTarefa("cadastrar","Tarefacadastarada");
        });

    }
}
