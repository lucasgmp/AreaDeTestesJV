package org.RegistrarTarefas;

import java.util.List;

public class TarefaService {


    private TarefaRepository repository = new TarefaRepository() {
        @Override
        public Tarefa BuscaPorNomes(String nome) {
            return null;
        }

        @Override
        public Tarefa buscarPorNome(String nome) {
            return null;
        }
    };
    private Tarefa Tarefa;

    public TarefaService(TarefaRepository dummy) {
        this.repository = dummy;
    }

    public TarefaService() {

    }


    public org.RegistrarTarefas.Tarefa cadastrarTarefa(String titulo, String descricao) {

        if (titulo == null || titulo.isEmpty()) {
            throw new IllegalArgumentException("Título é obrigatório");
        }

        org.RegistrarTarefas.Tarefa tarefa = new org.RegistrarTarefas.Tarefa(titulo, descricao);
        repository.salvar(Tarefa);

        return tarefa;
    }

    public List<Tarefa> listarTarefas() {
        return repository.listarTodas();
    }

    public void concluirTarefa(int index) {
        List<org.RegistrarTarefas.Tarefa> tarefas = repository.listarTodas();

        if (index < 0 || index >= tarefas.size()) {
            throw new IllegalArgumentException("Tarefa inexistente");
        }

        tarefas.get(index).concluir();
    }

    public Tarefa buscar(String qualquer) {
        return  Tarefa.buscarPorNome(qualquer);
    }
}