package org.RegistrarTarefas;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StubTest {

    @Test
    void deveRetornarStubTest() {

        TarefaRepository stub = new TarefaRepository() {

            @Override
            public void salvar(Tarefa tarefa) {

            }

            @Override
            public Tarefa BuscaPorNomes(String nome) {
                return null;
            }

            @Override
            public Tarefa buscarPorNome(String nome) {
                return new Tarefa("Estudar","Java");
            }
        };

        TarefaService service = new TarefaService(stub);

        Tarefa tarefa = service.buscar("qualquer");

        assertEquals("Estudar Java", tarefa.getTitulo());
    }
}
