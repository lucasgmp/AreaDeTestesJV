package org.RegistrarTarefas;

import java.util.ArrayList;
import java.util.List;

public abstract class TarefaRepository {

    private List<org.RegistrarTarefas.Tarefa> tarefas = new ArrayList<>();

    public void salvar(org.RegistrarTarefas.Tarefa tarefa) {
        tarefas.add(tarefa);
    }

    public List<org.RegistrarTarefas.Tarefa> listarTodas() {
        return tarefas;
    }


    public abstract Tarefa BuscaPorNomes(String nome);

    public abstract Tarefa buscarPorNome(String nome);
}
