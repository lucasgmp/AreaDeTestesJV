package org.RegistrarTarefas;

import org.junit.Test;
//import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TarefaServiceTest {

    @Test
    public void deveCadastrarTarefaComTituloValido() {
        org.RegistrarTarefas.TarefaService service = new org.RegistrarTarefas.TarefaService();

        org.RegistrarTarefas.Tarefa tarefa = service.cadastrarTarefa("Pagar boleto", "Conta de luz");

        assertNotNull(tarefa);
        assertEquals("Pagar boleto", tarefa.getTitulo());
        assertEquals("Pendente", tarefa.getStatus());
    }

    @Test
    public void naoDeveCadastrarSemTitulo() {
        org.RegistrarTarefas.TarefaService service = new org.RegistrarTarefas.TarefaService();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.cadastrarTarefa("", "Descrição");
        });

        assertEquals("Título é obrigatório", exception.getMessage());
    }

    @Test
    public void deveConcluirTarefa() {
        org.RegistrarTarefas.TarefaService service = new org.RegistrarTarefas.TarefaService();

        service.cadastrarTarefa("Estudar", "Prova");
        service.concluirTarefa(0);

        assertEquals("Concluída", service.listarTarefas().get(0).getStatus());
    }

    @Test
    public void naoDeveConcluirTarefaInexistente() {
        org.RegistrarTarefas.TarefaService service = new org.RegistrarTarefas.TarefaService();

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.concluirTarefa(0);
        });

        assertEquals("Tarefa inexistente", exception.getMessage());
    }
}