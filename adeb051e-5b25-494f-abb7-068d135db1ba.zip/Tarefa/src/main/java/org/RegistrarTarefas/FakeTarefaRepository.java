package org.RegistrarTarefas;

import java.util.ArrayList;
import java.util.List;

public class FakeTarefaRepository extends TarefaRepository {

    private List<Tarefa> tarefas = new ArrayList<>();

    @Override
    public void salvar(Tarefa tarefa) {
        tarefas.add(tarefa);
    }

    @Override
    public Tarefa BuscaPorNomes(String nome) {
        return null;
    }

    @Override
    public Tarefa buscarPorNome(String nome) {

        for(Tarefa t : tarefas) {

            if(t.getNome().equals(nome)) {
                return t;
            }
        }

        return null;
    }
}