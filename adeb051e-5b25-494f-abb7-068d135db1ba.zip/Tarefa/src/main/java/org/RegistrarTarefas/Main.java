package org.RegistrarTarefas;

public class Main {
    public static void main(String[] args) {

        TarefaService service = new TarefaService();

        service.cadastrarTarefa("Pagar boleto", "Conta de luz");
        service.cadastrarTarefa("Estudar Java", "TDD");

        service.concluirTarefa(0);

        for (Tarefa t : service.listarTarefas()) {
            System.out.println(t.getTitulo() + " - " + t.getStatus());
        }
    }
}
