package org.RegistrarTarefas;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class TarefaRepositoryTest {
    private List<Tarefa> tarefas = new ArrayList<>();

    public void salvar(Tarefa tarefa) {
        tarefas.add(tarefa);
    }

    public List<Tarefa> listarTodas() {
        return tarefas;
    }
}

