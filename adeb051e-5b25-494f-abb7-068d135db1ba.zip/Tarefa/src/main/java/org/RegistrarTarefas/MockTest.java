package org.RegistrarTarefas;

import org.junit.jupiter.api.Test;

import static jdk.internal.classfile.impl.verifier.VerifierImpl.verify;
import static jdk.jfr.internal.jfc.model.Constraint.any;
import static org.mockito.Mockito.*;

public class MockTest {


    @Test
    void deveSalvarTarefa() {

        TarefaRepository mockRepo = new MockTest(TarefaRepository.class);

        TarefaService service = new TarefaService(mockRepo);

        service.cadastrarTarefa("Estudar","java");

        verify(MockTest).salvar(any(Tarefa.class));
    }
}
