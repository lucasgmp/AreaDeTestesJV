package org.example;

public class Pedido {
    private double valorProduto;
    private boolean clienteVip;
    public Pedido(double valorProduto, boolean clienteVip) {
        this.valorProduto = valorProduto;
        this.clienteVip = clienteVip;
    }
    public double getValorProduto() {
        return valorProduto;
    }
    public  boolean isClienteVip() {
        return clienteVip;
    }
}
