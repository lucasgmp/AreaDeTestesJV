package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class CalcularPedidoTest {
    @Test
     void deveCobrarFreteQuandoPedidoForMenorQue150(){
        CalcularPedido calcular = new CalcularPedido();
        Pedido pedido = new Pedido(100.00,false);

        double Total = calcular.CalcularTotal(pedido);
        assertEquals(120,Total,0.01);
    }

    @Test
    void deveDarFreteGratisQuandoPedidoForIgualQue150(){
        CalcularPedido calcular = new CalcularPedido();
        Pedido pedido = new Pedido(150.00,false);

        double Total = calcular.CalcularTotal(pedido);
        assertEquals(150,Total,0.01);
    }
    @Test
    void deveAplicarDescontoParaClienteVip(){
        CalcularPedido calcular = new CalcularPedido();
        Pedido pedido = new Pedido(200.00,true);

        double Total = calcular.CalcularTotal(pedido);
        assertEquals(190.00,Total,0.01);
    }

}
