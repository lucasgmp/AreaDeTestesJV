package org.example;

public class CalcularPedido {
    public double CalcularTotal(Pedido pedido) {
            double total = pedido.getValorProduto();


            if(pedido.isClienteVip()){
                total = total * 0.95;
            }
            if(total<150){
               total = total + 20;
            }
            return total;
    }
}
